from django.contrib import admin
from django.db.models.base import Model

# Register your models here.
from .models import staff
from .models import player
from .models import coach
from .models import fixtures
from .models import matchresult
from .models import clubimage
 


class Addstaff(admin.ModelAdmin):
    list_display = ['title']

admin.site.register(staff,Addstaff)


class Addplayer(admin.ModelAdmin):
    list_display = ["name", "player_position","age" , "match_played", "goal_scored", "player_image", "description"]
admin.site.register(player,Addplayer)


class Addcoach(admin.ModelAdmin):
    list_display = ["name", "coach_position", "coach_image", "age", "description"]
admin.site.register(coach,Addcoach)

 
class Addfixtures(admin.ModelAdmin):
    list_display = ["clubname", "opponent", "date","time","stadium"]
admin.site.register(fixtures,Addfixtures)

class Addmatchresult(admin.ModelAdmin):
    list_display = ["clubname","opponent", "date", "stadium"]
admin.site.register(matchresult,Addmatchresult)

class Addclubimage(admin.ModelAdmin):
    list_display = ["img"]
admin.site.register(clubimage,Addclubimage)