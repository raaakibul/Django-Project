from django.http import HttpResponse
from django.shortcuts import render

#function
def players(request):
    return render(request,'player/players.html')

def coach(request):
    return render(request,'player/coach.html')