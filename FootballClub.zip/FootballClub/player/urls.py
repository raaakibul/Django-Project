from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import path,include
from .import views

urlpatterns = [ 
    path('', views.players),
    path('coach/', views.coach),
    path('players/', views.players)
]

# urlpatterns += staticfiles_urlpatterns()

