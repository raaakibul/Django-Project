from django.db import models

# Create your models here.
class staff(models.Model):
    title = models.CharField(max_length=100, null=True)

    class Meta:
        verbose_name_plural = "Staff"

    def __str__(self):
        return self.title

class player(models.Model):
    name = models.CharField(max_length=50)
    player_position= models.ForeignKey('staff', on_delete = models.CASCADE)
    age = models.IntegerField()
    match_played= models.IntegerField()
    goal_scored = models.IntegerField()
    player_image = models.ImageField(upload_to = "playerImage/",null=True)
    description= models.TextField(max_length=200, null=True)


    class Meta:
        verbose_name_plural = "Player"


    def __str__(self):
        return f"{self.name} : {self.player_position} :{self.age } :{self.match_played}: {self.goal_scored} : {self.player_image}: {self.description}" 

class coach(models.Model):
    name= models.CharField(max_length=50)
    coach_position = models.ForeignKey('staff', on_delete = models.CASCADE)
    coach_image = models.ImageField(upload_to = "coachImage/",null=True)
    age = models.IntegerField()
    description= models.TextField(max_length=400, null=True)

    class Meta:
        verbose_name_plural = "Coach"

    def __str__(self):
        return f"{self.name} : {self.coach_position} :{self.coach_image }:{self.age} : {self.description}"    


class fixtures(models.Model):
    clubname = models.CharField(max_length=64,null=True)
    opponent= models.CharField(max_length=64,null=True)
    date = models.DateField(null=True)
    time = models.TimeField(null=True)
    stadium = models.CharField(max_length=64, null=True)

    class Meta:
        verbose_name_plural = "fixture"       
        

class matchresult(models.Model):
      clubname = models.CharField(max_length=64,null=True)
      opponent= models.CharField(max_length=64,null=True)
      date = models.DateField(null=True)
      stadium = models.CharField(max_length=64, null=True)
     
      class Meta: 
          verbose_name_plural = "matchresult"

      def __str__(self):
            return f"{self.clubname} : {self.opponent} {self.date}: {self.stadium}" 

class clubimage(models.Model):
    img = models.ImageField(upload_to = "clubimage/",null=True)

    class Meta:
        verbose_name_plural = "clubimage"

    def __str__(self):
        return f"{self.img}"
