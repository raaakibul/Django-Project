const login_info_btn = document.getElementsByClassName("login_info-btn")
for (let i = 0; i < login_info_btn.length; i++) {
  login_info_btn[i].onclick = () => {
    document.querySelector(".login_container").classList.toggle("log-in");
  }; 
}
