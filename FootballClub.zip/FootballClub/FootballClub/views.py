from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate 
from player.models import clubimage
from player.models import player
from player.models import fixtures
from player.models import matchresult
from player.models import coach
def home(request):
     return render(request,'home.html')

def clubs(request):
     playersdata= player.objects.all()
     playercontext={
          'clubs' : playersdata 
           
     }
     return render(request,'clubs.html',playercontext)

def manager(request):
    coachdata = coach.objects.all()
    coachcontext = {
         'manager' : coachdata
    }

    return render(request, 'manager.html', coachcontext)

def video(request):
     return render(request,'video.html')

def gallery(request):
     imagedata = clubimage.objects.all()
     imagecontext={
          'gallery':imagedata
     } 
     
     return render(request, 'gallery.html',imagecontext)

 
def fixture(request):
     fixturesdata= fixtures.objects.all()
     fixturecontext = {
          'fixture':fixturesdata
     }
     return render(request,'fixture.html',fixturecontext)  

def result(request):
     resultdata= matchresult.objects.all()
     resultcontext = {
          'result':resultdata
     }

     return render(request, 'result.html',resultcontext)     
     

def login(request):
     if request.method =="POST":
          name = request.POST["name"]
          password = request.POST["password"]
          user = authenticate(request, username = name, password= password)

          if user is not None:
               login(request,user)
               return redirect("profile")

          else:
               print("Invalid username or password")

     return render(request, 'login.html')          
