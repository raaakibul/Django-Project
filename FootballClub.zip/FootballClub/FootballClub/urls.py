
from django.contrib import admin
from django.urls import path,include
from.import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', views.home, name='home'),
    path('clubs/', views.clubs, name='clubs'),
    path('manager/', views.manager, name='manager'),
    path('video/',views.video, name="video"),
    path('gallery/',views.gallery, name="gallery"),    
    path('fixture/',views.fixture, name="fixture"),   
    path('result/',views.result, name="result"),   
    path('login/',views.login, name="login"),   
    path('player/', include('player.urls')),

]
urlpatterns= urlpatterns+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


